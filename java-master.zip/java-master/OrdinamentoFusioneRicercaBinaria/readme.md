# ordinamento per fusione
# ricerca binaria
