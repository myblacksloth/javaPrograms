package com_antomau_OrdFusRicBin.UserInterface;

import com_antomau_OrdFusRicBin.OdinamentoFusione.OrdinamentoFusione;
import com_antomau_OrdFusRicBin.RicercaBinaria.BinarySearch;

import java.util.Scanner;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.Arrays;

/**
 * 
 * @author Antonio Maulucci
 *
 */
public class UserOrdFusRicBin {
	
	private static File file; //nuovo file
	
	private static Scanner in; //nuovo scanner
	
	/*
	 * fileLoaded -> verifica che il file sia stato correttaamente caricato
	 * arraySorted -> verifica che l'array sia stato ordinato
	 */
	private static boolean fileLoaded = false, arraySorted = false;
	
	private static int[] array;
	
	public static void main(String[] args) {
		
		
		JFrame f = new JFrame("OrdFus-RicBin");
		f.setSize(300, 300);
		f.setLayout(new BorderLayout());
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel fileFinder = new JPanel();
		fileFinder.setLayout(new GridLayout(1,3));
		
		JFileChooser fileChooser = new JFileChooser();
		
		JLabel choosenFileName = new JLabel(""); 
		JButton openFileButton = new JButton("Open database");
		JButton exitButton = new JButton("Exit");
		
		fileFinder.add(choosenFileName);
		fileFinder.add(openFileButton);
		fileFinder.add(exitButton);
		
		
		JPanel contentPanel = new JPanel();
		contentPanel.setLayout(new BorderLayout());
		
		JPanel consolePanel = new JPanel();
		consolePanel.setLayout(new GridLayout(1,4));
		
		JButton printArrayButton = new JButton("Print data");
		JButton sortButton = new JButton("Sort");
		JTextField searchField = new JTextField();
		JButton searchButton = new JButton("Search");
		
		consolePanel.add(printArrayButton);
		consolePanel.add(sortButton);
		consolePanel.add(searchField);
		consolePanel.add(searchButton);
		
		JPanel mainContents = new JPanel();
		
		contentPanel.add(consolePanel, BorderLayout.NORTH);
		contentPanel.add(mainContents, BorderLayout.CENTER);
		
		f.add(fileFinder, BorderLayout.NORTH);
		f.add(contentPanel, BorderLayout.CENTER);
		
		
		f.pack();
		
		class openFileListenerClass implements ActionListener {
			@Override
			public void actionPerformed(ActionEvent e) {
				fileChooser.showOpenDialog(f); //questa istruzione visualizza la finestra di dialogo per la scleta del file all'interno del frame f
				try {
					file = fileChooser.getSelectedFile();
					in = new Scanner(file); //creare uno scanner per il file "file"
					fileLoaded = true; //diventa vera perché il file è stato caricato
					
				} catch (FileNotFoundException exc) {
					exc.printStackTrace();
				} //end of try/catch
				
				/*
				 * 
				 */
				/*
				 * FUNZIONAMENTO DELLO SCANNER IN JAVA
				 * per quanto riguarda i file lo scannner ha a disposizione diversi metodi
				 * alcuni dei quali servono a verificare che esista uno specifico dato
				 * (es.: hasNext() e hasNextInt())
				 * e altri che servono a prendere l'elemento
				 * (es.: next() e nextInt())
				 * mentre i primi verificano solamente la presenza di un elemento
				 * i secondi prendono l'elemento ma fanno scorrere in avanti lo scanner
				 *
				 * file -> numbers.dat
				 * 1 ciao 2 lello 3 pappagallo
				 *
				 * il metodo hasNextInt() restituirà true perché il primo elemento è vero
				 * ma non farà scorrere lo scanner verso "lello"
				 * pertanto se andiamo ad implementare un ciclo while su tale metodo dello scanner si genererà un loop infinito in quanto il metodo restituirà sempre true perché non avanzerà all'interno del file
				 * while (scanner.hasNextInt()) counter++;
				 * farà incrementare il valore di counter all'infinito
				 * ma se all'interno del while poniamo un metodo che faccia scorrere lo scanner il problema si risolve
				 * while (scanner.hasNext()) {
				 *	counter++;
				 * scanner.next(); //fa scorrere lo canner in avanti
				 * }
				 * 
				 * inolre occorre resettare (inizializzare nuovamente) lo scanner ogni volta che si intende scansionare il file dall'inizio
				 */
				if (fileLoaded) //se il file è stato caricato il codice seguente viene eseguito
				{
					int values = 0; //questo valore memorizza il numero di interi presenti nel file
					while (in.hasNext()) //fintanto che nel file sia presente un token...
					{
						if (in.hasNextInt()) values++; //se il prossimo elemento dello scanner è un intero incrementa la variabile "values"
						in.next(); //fa scorrere lo scanner verso il token successivo
					} //end of while
					/*
					 * viene creata la variabile i che costituisce l'indice dell'array in cui inserire il dato
					 * essa viene inizializzata a (-1) per uno scopo ben preciso
					 *
					 * se fosse stata inizializzata a 0
					 * nel ciclo while per il riempimento dell'array
					 * si sarebbe dovuto prima inserire il dato e poi incrementare l'indice
					 * ma così facendo si sarebbe arrivati all'ultimo elemento dell'array
					 * dove andando ad incrementare l'indice si sarebbe proceduto verso una posizione inesistente
					 *
					 * mentre inzializzando la variabile a (-1)
					 * nel ciclo while per il rimepimento dell'array
					 * si incrementa prima l'indice dell'array
					 * e poi si inserisce il dato
					 * in questo modo quando si giunge all'ultimo dato viene posizionato l'indice nella posizione corretta, viene inserito il dato e si esce dal ciclo senza avanzare verso una posizione inesistente
					 */
					int i=-1;
					array = new int[values]; //l'array finalizzato ad ospitare i dati viene inizlizzato a "values" posizioni che corrispondono al numero di interi che questo deve ospitare
					/*
					 * Mediante la gestione delle eccezioni try/catch
					 viene nuovamente inizializzato lo scanner
					 al fine di poter scansionare il file nuovamente dall'inizio
					 */
					try {
						in = new Scanner(file);
					} catch (Exception exc) {
						System.exit(1); //se non si riesce ad inizializzare lo scanner il programma interrompe la propria esecuzione resituendo l'errore "1"
					}
					while (in.hasNext()) //fintanto che nel file sia presente un token...
					{
						if (in.hasNext()) //fintanto che nel file sia presente un token
						{
							if (in.hasNextInt()) { //se il prossimo token è un numero intero
								i++; //incrementa l'indice dell'array
								array[i] = in.nextInt(); //memorizza il token convertito in intero nella posizione i dell'array --- nextInt() fa scorrere lo scanner in avanti
							} else { //altrimenti se il prossimo token non è un numero intero
								in.next(); //scorri il file facendo scorrere lo scanner in avanti
							} //end of else
							
							
						} //end of if
					} //end of while
				} //end of if fileloaded
				
				choosenFileName.setText(fileChooser.getName(file));
				arraySorted = false;
			}
		} //end of selectFileListenerClass
		
		ActionListener openFileListener = new openFileListenerClass();
		openFileButton.addActionListener(openFileListener);
		
		
		class exitListenerClass implements ActionListener {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		} //end of openFileListenerClass
		
		ActionListener exitListener = new exitListenerClass();
		exitButton.addActionListener(exitListener);
		
		class printDataButtonListenerClass implements ActionListener {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (fileLoaded) {
					mainContents.removeAll();
					JLabel printArrayLabel = new JLabel(Arrays.toString(array));
					mainContents.add(printArrayLabel);
					f.pack();
				} //end of if
			}
		} //end of openFileListenerClass
		
		ActionListener printDataListener = new printDataButtonListenerClass();
		printArrayButton.addActionListener(printDataListener);
		
		
		
		class sortButtonListenerClass implements ActionListener {
			@Override
			public void actionPerformed(ActionEvent e) {
				/*
				 * []color of sort button
				 * [x]sorted array true/false
				 */
				
				OrdinamentoFusione mergesorter = new OrdinamentoFusione(array);
				array = mergesorter.getArray();
				arraySorted = true;
			}
		} //end of openFileListenerClass
		
		ActionListener sortButtonListener = new sortButtonListenerClass();
		sortButton.addActionListener(sortButtonListener);
		
		
		
		class searchButtonListenerClass implements ActionListener {
			@Override
			public void actionPerformed(ActionEvent e) {
				mainContents.removeAll();
				JLabel findResult = new JLabel();
				if (arraySorted)
				{
					BinarySearch searcher = new BinarySearch(array, Integer.parseInt(searchField.getText()));
					int result = searcher.find();
					if (result < 0) findResult.setText("Searched value was not found");
					else findResult.setText("<html>Searched value was found in \"<b>" + result + "</b>\" position of array</html>");
				}  else findResult.setText("<html><b>You haven't sorted the array! Do it and try again!</b></html>");
				mainContents.add(findResult);
				f.pack();
			}
		} //end of openFileListenerClass
		
		ActionListener searchButtonListener = new searchButtonListenerClass();
		searchButton.addActionListener(searchButtonListener);
		
	} //end of main
	

} //end of class
