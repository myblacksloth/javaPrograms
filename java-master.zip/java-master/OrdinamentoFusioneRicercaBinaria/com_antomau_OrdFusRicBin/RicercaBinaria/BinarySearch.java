package com_antomau_OrdFusRicBin.RicercaBinaria;

/**
 * Questa classe si occupa della ricerca binaria all'interno dell'array
 * @author Antonio Maulucci
 */
public class BinarySearch {
	
	//variabili
	int[] a; //array in cui effettuare la ricerca
	int f; //intero da cercare nell'array
	
	/**
	 * Questo è il metodo costruttore della classe
	 * @param a L'array di interi in cui cercare il valore
	 * @param f Il numero di intero da cercare all'interno dell'array
	 */
	public BinarySearch(int[] a, int f)
	{
		this.a = a;
		this.f = f;
	} //end of builder
	
	/**
	 * Questo metodo ricerca il valore all'intero dell'array
	 * @return La posizione in cui si trova il valore cercato, se l'elemento non è presente nell'array restituisce (-1)
	 */
	public int find()
	{
		int low=0; //1st array's position
		int high = (a.length)-1; //last array's position
		
		while (low < high)
		{
			int mid = (low+high)/2; //middle position of array
				
			int diff = a[mid]-f; //questa variabile salva la differenza tra l'elemento nel punto medio dell'array e il valore cercato
			
			if (diff == 0) //se la differenza è 0 vuol dire che l'elemento è stato trovato
			{
				return mid; //il metodo restituisce la posizione dell'elemento trovato
			} else if (diff>0) { //se la differenza è maggiore di 0 vuol dire che l'elemento cercato si trova a sinistra del punto medio
				high = mid-1; //la parte di array considerata viene ridimensionata scalando l'indice massimo verso sinistra
			} else { //se la differenza è minore di 0 l'elemento cercato si trova a destra del punto medio
				low = mid+1; //la parte di array considerata viene ridimensionata scalando l'indice minimo verso destra
			} //end of if/else
		} //end of while
		
		return -1;
	} //end of find

} //end of class
