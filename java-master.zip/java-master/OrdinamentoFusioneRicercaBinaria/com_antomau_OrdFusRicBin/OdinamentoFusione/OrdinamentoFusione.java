package com_antomau_OrdFusRicBin.OdinamentoFusione;

import java.util.Arrays;

/**
 * Questa classe si occupa dell'ordinamento per fusione di un array
 * @author Antonio Maulucci
 */
public class OrdinamentoFusione {
	
	//variables
	int[] a;
	
	//builder
	public OrdinamentoFusione(int[] a)
	{
		this.a = a; //viene inizializzata la variabile d'istanza a con la variabile a passata dal metodo chiamante
		sort(); //viene chiamato il metodo sort che si occupa di ordinare l'array
	} //end of builder
	
	
	public void sort()
	{
		
		int[] firsthalf, secondhalf; //queste variabili si occupano di memeorizzare rispettivamente la prima e la seconda metà dell'array originario
		
		if (a.length<=1)
		{
			return; //quando la lunghezza è 1 o inferiore a 1 vuol dire che l'array è già ordinato
		} else {
			firsthalf = new int[a.length/2]; //l'array dedito al contenimento della prima metà dell'array viene inizializzato e le sue posizioni saranno la metà di quelle dell'array originario
			secondhalf = new int[(a.length)-(firsthalf.length)]; //l'array dedito al contenimento della seconda metà dell'array viene inizializzato al fien di avere le posizioni rimanente dell'array originario ovvero (posizioni dell'array originario - posizioni dell'array che contiene la prima metà)
			for (int i=0; i<firsthalf.length; i++) {
				firsthalf[i] = a[i];
			} //end of firsthalf's for
			int j=firsthalf.length;
			for (int i=0; i<secondhalf.length; i++) {
				secondhalf[i] = a[j];
				j++;
			} //end of secondhalf's for
			System.out.println("array 1 is = " + Arrays.toString(firsthalf) + " 2nd is = " + Arrays.toString(secondhalf)); //debug
			OrdinamentoFusione firstsorter = new OrdinamentoFusione(firsthalf);
			OrdinamentoFusione secondsorter = new OrdinamentoFusione(secondhalf);
			firstsorter.sort();
			secondsorter.sort();
			merge(firsthalf, secondhalf);
		} //end of else
	} //end of sort
	
	
	
	public void merge(int[] firsthalf, int[] secondhalf)
	{
		int ifst=0, isnd=0, j=0; //indici per gli array firsthalf, secondhalf e per l'array originario
		
		while (ifst < firsthalf.length && isnd < secondhalf.length)
		{
			if (firsthalf[ifst] < secondhalf[isnd])
			{
				a[j] = firsthalf[ifst];
				ifst++;
			} else {
				a[j] = secondhalf[isnd];
				isnd++;
			} //end of else
			j++;
		} //end of while
		System.out.println("a array now is = " + Arrays.toString(a)); //debug
		while (ifst < firsthalf.length) //while per i valori restanti nell'array firsthalf
		{
			a[j] = firsthalf[ifst];
			ifst++;
			j++;
		} //end of while valori_restanti_firsthalf
		while (isnd < secondhalf.length) { //while per i valori restanti nell'array secondhalf
			a[j] = secondhalf[isnd];
			isnd++;
			j++;
		} //end of while valori_restanti_secondhalf
		System.out.println("now a array is = " + Arrays.toString(a)); //debug
		
	} //end of merge
	
	
	public int[] getArray()
	{
		return a;
	}
	
} //end of class
