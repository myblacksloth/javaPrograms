# tabelle hash
