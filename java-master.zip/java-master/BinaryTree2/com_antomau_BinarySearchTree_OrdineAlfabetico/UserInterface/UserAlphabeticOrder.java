package com_antomau_BinarySearchTree_OrdineAlfabetico.UserInterface;

import com_antomau_BinarySearchTree_OrdineAlfabetico.Tree.BinarySearchTree;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;

/**
 * @author Antonio Maulucci http://www.antomau.com
 */
public class UserAlphabeticOrder {
	
	
	
	
	private static BinarySearchTree myTree = new BinarySearchTree();
	
	
	
	private static Scanner in;
	
	
	private static File file;
	
	
	
	public static void main(String[] args) {
		
		JFrame f = new JFrame("Antonio Maulucci's Alphabetic Order");
		f.setSize(300, 300);
		f.setLayout(new BorderLayout());
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel console = new JPanel();
		console.setLayout(new GridLayout(1,6));
		
		JButton loadButton = new JButton("Open file");
		JButton printButton = new JButton("Print ordered words");
		JButton saveButton = new JButton("Save file");
		JButton exitButton = new JButton("Exit");
		JButton findButton = new JButton("Find word");
		JButton removeButton = new JButton("Remove word");
		
		console.add(loadButton); //1,1
		console.add(printButton); //1,2
		console.add(findButton); //1,3
		console.add(removeButton); //1,4
		console.add(saveButton); //1,5
		console.add(exitButton); //1,6
		
		JPanel contentPanel = new JPanel();
		
		f.add(console, BorderLayout.NORTH);
		f.add(contentPanel, BorderLayout.CENTER);
		
		f.pack();
		
		
		JFileChooser fc = new JFileChooser();
		
		
		
		class exitButtonListenerClass implements ActionListener
		{
			@Override
			public void actionPerformed (ActionEvent e)
			{
				System.exit(0);
			} //end of actionPerformed
		} //end of exitButtonListenerClass
		
		ActionListener exitButtonListener = new exitButtonListenerClass();
		exitButton.addActionListener(exitButtonListener);
		
		
		
		
		
		
		
		class loadButtonListenerClass implements ActionListener
		{
			@Override
			public void actionPerformed (ActionEvent e)
			{
				fc.setDialogTitle("Choose file to open");
				fc.showOpenDialog(f);
				try {
					file = fc.getSelectedFile();
					in = new Scanner(file);
				} catch (Exception exc) {
					exc.printStackTrace();
					return;
				} //end of try/catch
				
				while (in.hasNext())
				{
					myTree.add(in.next().toUpperCase());
				} //end of while
				
			} //end of actionPerformed
		} //end of exitButtonListenerClass
		
		ActionListener loadButtonListener = new loadButtonListenerClass();
		loadButton.addActionListener(loadButtonListener);
		
		
		
		
		
		
		class printButtonListenerClass implements ActionListener
		{
			@Override
			public void actionPerformed (ActionEvent e)
			{
				contentPanel.removeAll();
				contentPanel.add(new JLabel(myTree.toString()));
				f.pack();
			} //end of actionPerformed
		} //end of exitButtonListenerClass

		ActionListener printButtonListener = new printButtonListenerClass();
		printButton.addActionListener(printButtonListener);
		
		
		
		
		
		
		
		
		
		
		
		
		
		class findButtonListenerClass implements ActionListener
		{
			@Override
			public void actionPerformed (ActionEvent e)
			{
				contentPanel.removeAll();
				
				JPanel internalPanel = new JPanel();
				internalPanel.setLayout(new GridLayout(1,3));
				
				JLabel l = new JLabel("Word to find:");
				JTextField jtf = new JTextField();
				JButton button = new JButton("Find");
				
				internalPanel.add(l);
				internalPanel.add(jtf);
				internalPanel.add(button);
				
				contentPanel.add(internalPanel);
				
				class buttonListenerClass implements ActionListener
				{
					@Override
					public void actionPerformed(ActionEvent e)
					{
						JLabel resultLabel = new JLabel();
						if (myTree.find(jtf.getText().toUpperCase())) resultLabel.setText("FOUND");
						else resultLabel.setText("NOT FOUND");
						contentPanel.removeAll();
						contentPanel.add(resultLabel);
						f.pack();
					} //end of internal actionPerformed
				} //end of buttonListenerClass
				
				button.addActionListener(new buttonListenerClass());
				
				
				f.pack();
			} //end of actionPerformed
		} //end of exitButtonListenerClass
		
		ActionListener findButtonListener = new findButtonListenerClass();
		findButton.addActionListener(findButtonListener);
		
		
		
		
		
		
		
		
		
		
		
		class removeButtonListenerClass implements ActionListener
		{
			@Override
			public void actionPerformed (ActionEvent e)
			{
				contentPanel.removeAll();
				
				JPanel internalPanel = new JPanel();
				internalPanel.setLayout(new GridLayout(1,3));
				
				JLabel l = new JLabel("Word to remove:");
				JTextField jtf = new JTextField();
				JButton button = new JButton("Remove");
				
				internalPanel.add(l);
				internalPanel.add(jtf);
				internalPanel.add(button);
				
				contentPanel.add(internalPanel);
				
				class buttonListenerClass implements ActionListener
				{
					@Override
					public void actionPerformed(ActionEvent e)
					{
						myTree.remove(jtf.getText().toUpperCase());
					} //end of internal actionPerformed
				} //end of buttonListenerClass
				
				button.addActionListener(new buttonListenerClass());
				
				f.pack();
			} //end of actionPerformed
		} //end of exitButtonListenerClass
		
		ActionListener removeButtonListener = new removeButtonListenerClass();
		removeButton.addActionListener(removeButtonListener);
		
		
		
		
		
		
		
		
		
		class saveButtonListenerClass implements ActionListener
		{
			@Override
			public void actionPerformed (ActionEvent e)
			{
				fc.setDialogTitle("Choose a file to save");
				fc.showSaveDialog(f);
				PrintWriter outfile;
				try {
					outfile = new PrintWriter(fc.getSelectedFile());
				} catch(Exception exc) {
					exc.printStackTrace();
					return;
				} //end of try/catch
				
				outfile.print(myTree.toString());
				
				outfile.close();
				
			} //end of actionPerformed
		} //end of exitButtonListenerClass
		
		ActionListener saveButtonListener = new saveButtonListenerClass();
		saveButton.addActionListener(saveButtonListener);
		
		
		
		
		
		
		
		
		
	} //end of main
} //end of class
