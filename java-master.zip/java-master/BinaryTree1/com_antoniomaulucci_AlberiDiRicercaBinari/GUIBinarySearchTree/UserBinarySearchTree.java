package com_antoniomaulucci_AlberiDiRicercaBinari.GUIBinarySearchTree;

import com_antoniomaulucci_AlberiDiRicercaBinari.BinarySearchTree.BinarySearchTree;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout; //border layout for frame and panels
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserBinarySearchTree {
	
	
	
private static final int xs=300, ys=300;
	
	private static BinarySearchTree tree = new BinarySearchTree();
	
	public static void main(String[] args)
	{
		
		
		//new frame and settings
		JFrame f = new JFrame("Integers Binary Search Tree");
		f.setSize(xs, ys);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		f.pack();
		f.setLayout(new BorderLayout());
		
		
		//console panel and settings
		JPanel console = new JPanel();
		console.setLayout(new GridLayout(1,2));
		
		JPanel buttonsConsole = new JPanel();
		buttonsConsole.setLayout(new GridLayout(4,2));
		JButton addb = new JButton("Add");
		JButton findb = new JButton("Find");
		JButton removeb = new JButton("Remove");
		JButton printb = new JButton("Print");
		JButton clearb = new JButton("Clear interface");
		JButton exitb = new JButton("Exit");
		JButton buildb = new JButton("PreBuild tree");
		buttonsConsole.add(addb);
		buttonsConsole.add(findb);
		buttonsConsole.add(removeb);
		buttonsConsole.add(printb);
		buttonsConsole.add(clearb);
		buttonsConsole.add(exitb);
		buttonsConsole.add(buildb);
		
		JTextField tf = new JTextField();
		
		console.add(tf); //position 1,1
		console.add(buttonsConsole); //position 1,2
		
		JLabel copyg = new JLabel("Use this software only with integer values - ©aMaulucci");
		
		JPanel contents = new JPanel();
		
		//add elements to frame
		f.add(console, BorderLayout.NORTH);
		f.add(copyg, BorderLayout.SOUTH);
		f.add(contents, BorderLayout.CENTER);
		
		class addListenerClass implements ActionListener {
			@Override
			public void actionPerformed(ActionEvent e) {
				contents.removeAll(); //clear the contents panel
				f.pack();
				JLabel result = new JLabel("Added");
				tree.add(Integer.parseInt(tf.getText()));
				JPanel intContents = new JPanel();
				intContents.add(result);
				contents.add(intContents);
				f.pack();
			}
		}
		ActionListener addListener = new addListenerClass();
		addb.addActionListener(addListener);
		
		class findListenerClass implements ActionListener {
			@Override
			public void actionPerformed(ActionEvent e) {
				contents.removeAll();
				f.pack();
				JLabel result = new JLabel();
				if (tree.find(Integer.parseInt(tf.getText()))) {
					JPanel intContents = new JPanel();
					intContents.setBackground(Color.green);
					result.setText("FOUND");
					intContents.add(result);
					contents.add(intContents);
					f.pack();
				} else {
					JPanel intContents = new JPanel();
					intContents.setBackground(Color.red);
					result.setText("NOT FOUND");
					intContents.add(result);
					contents.add(intContents);
					f.pack();
				} //end of else
			}
		}
		
		ActionListener findListener = new findListenerClass();
		findb.addActionListener(findListener);
		
		class removeListenerClass implements ActionListener {
			@Override
			public void actionPerformed(ActionEvent e) {
				contents.removeAll(); //clear the contents panel
				f.pack();
				JLabel result = new JLabel();
				if (tree.find(Integer.parseInt(tf.getText()))) {
					tree.remove(Integer.parseInt(tf.getText()));
					result.setText("Removed");
				}
				else result.setText("Value to remove was not found");
				JPanel intContents = new JPanel();
				intContents.add(result);
				contents.add(intContents);
				f.pack();
			}
		}
		ActionListener removeListener = new removeListenerClass();
		removeb.addActionListener(removeListener);
		
		
		class printListenerClass implements ActionListener {
			@Override
			public void actionPerformed(ActionEvent e) {
				contents.removeAll(); //clear the contents panel
				f.pack();
				JLabel result = new JLabel(tree.printGui());
				JPanel intContents = new JPanel();
				intContents.add(result);
				contents.add(intContents);
				f.pack();
			}
		}
		ActionListener printListener = new printListenerClass();
		printb.addActionListener(printListener);
		
		
		class clearListenerClass implements ActionListener {
			@Override
			public void actionPerformed(ActionEvent e) {
				tf.setText(null);
				contents.removeAll();
				f.pack();
			}
		}
		ActionListener clearListener = new clearListenerClass();
		clearb.addActionListener(clearListener);
		
		
		
		class exitListenerClass implements ActionListener {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		}
		ActionListener exitListener = new exitListenerClass();
		exitb.addActionListener(exitListener);
		
		
		
		class buildListenerClass implements ActionListener {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if (!tree.find(10)) tree.add(10);
				if (!tree.find(8)) tree.add(8);
				if (!tree.find(16)) tree.add(16);
				if (!tree.find(6)) tree.add(6);
				if (!tree.find(9)) tree.add(9);
				if (!tree.find(11)) tree.add(11);
				if (!tree.find(26)) tree.add(26);
				if (!tree.find(3)) tree.add(3);
				if (!tree.find(7)) tree.add(7);
				if (!tree.find(20)) tree.add(20);
				if (!tree.find(30)) tree.add(30);
			}
		}
		ActionListener buildListener = new buildListenerClass();
		buildb.addActionListener(buildListener);
		
		
	} //end of main
	

} //end of class