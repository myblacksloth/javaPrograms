/*
 * © Antonio Maulucci 2016
 * ALBERI DI RICERCA BINARI
 * In un insieme si possono sistemare gli elementi come si preferisce al fine di poterli ritrovare più velocemente
 * Sei dati sono ordinati si può utilizzare la ricerca binaria per trovarli velocemente.
 * La richerca binaria richiede O(log(n)) passi per trovare un elemento, dove n è la dimensione dell'insieme.
 * La ricerca binaria in un array di 1000 elementi è in grado di trovare un elemento in circa 10 passi.
 * Se inseriamo i dati nell'insieme seguendo un ordine particolare, l'inserimento e la rimozione sono O(n) operazioni.
 * 
 * Le strutture di dati a forma di albero possono conservare gli elementi di un insieme in ordine, consentendo inserimenti e rimozioni molto efficienti
 * Una struttura a forma di albero può essere considerata l'opposto di una lista concatenata
 * Perché, mentre la lista concatenata ha una sola dimensione e ciascun nodo ha un collegamento al nodo successivo,
 * Un albero è costituito da nodi che hanno più riferimenti ad altri nodi.
 * Un nodo puà avere riferimenti ad altri nodi chiamati figli. I nodi figli possono avere altri figli
 * Questa struttura somiglia ad un albero il quale viene disegnato con la radice in alto.
 * 
 * Il nodo che si trova in cima all'albero è detto nodo radice (root node).
 * I nodi privi di figli si dicono nodi foglie (leaf node).
 * In un albero binario un nodo può avere al massimo due figli (destro e sinistro).
 * Un albero binario deve essere costruito secondo questa proprietà fondamentale:
 * (1) Considerato un nodo come nodo corrente
 * (2) il suo discendente sinistro deve avere obbligatoriamente un valore inferiore al nodo corrente
 * (3) il suo discendente destro deve avere un valore obbligatoriamente maggiore al nodo corrente
 * esempio:
 						nodo corrente = eve
figlio sinistro = adam						figlio destro = harry
adaa			adaz							harra			harrz
 * 
 * 
 * 
 * PER INSERIRE DATI NELL'ALBERO
 * Per inserire i dati nell'albero si utilizza il seguente algoritmo:
 * (1) se analizzo l'albero partendo dalla radice, nodo per nodo
 * (2) se il nodo che si sta analizzando ha un valore diverso da null:
 * (2a) se il valore da inserire è minore di quello contenuto nel nodo, si continua il processo nel sottoalbero sinistro
 * (2b) altrimenti si continua il processo nel sottoalbero destro
 * (3) se il nodo che si sta analizzando è null si sostituisce in quel nodo con il nuovo nodo.
 * esempio:
							BinarySearchTree
											Figlio dx = Juliet
						Figlio sx =  Diana					Figlio dx = Tom
										Figlio dx = Harry
 *
 * si vuole aggiungere Romeo all'abero di ricerca binaria
 * (1) si incomincia scandendo l'albero dalla radice
 * (2) la radice dell'albero è "Juliet"
 * (3) il valore che si vuole inserire (Romeo) è maggiore rispetto a quello della radice
 * (4) quindi ci dobbiamo spostare nel sottoalbero destro
 * (5) nel sotto albero destro c'è il valore "Tom" il quale è maggiore rispetto a quello che si vuole inserire
 * (6) quindi ci spostiamo nel suo sottoalbero sinistro
 * (7) il sottoalbero sinistro non esiste pertanto aggiungeremo un nuovo nodo contenente il nuovo dato
 * (8) avremmo aggiunto quindi un nuovo nodo che è il figlio sinistro di "Tom"
 * ovvero:
 					ROOT
						\
					     \
					      \
					       \
					       	Juliet
							 /	\
					      	/	 \
					       /	  	  \
			  		      /		   \
				       Diana       Tom
				       	\			/
				    	 	 \		   /
				   	      \		  /
				   	  	   \	    Romeo
				   	   	 Harry
 * 
 * Se l'albero è vuoto si deve usare il nuovo nodo come radice.
 * Diversamente, l'oggetto di tipo nodo invocherà il metodo addNode che andrà a verificare quale sia la posizione corretta per l'inserimento dell'elemento.
 * Un albero binario non è dotato di posizioni di inserimento pertanto non è possibile scegliere la posizione in cui inserire un elemento.
 * 
 * 
 * 
 * Ogni il nodo di un albero binario contiene un dato, un riferimento al nodo figlio sinistro e un riferimento al nodo figlio destro.
 * 
 * 
 * 
 * 
 * RIMOZIONE DI UN ELEMENTO DALL'ALBERO
 * (1) considerata la proprietà caratteristica degli alberi di ricerca binaria, si confronta il valore del dato da rimuovere con il valore del dato memorizzato nel nodo radice
 * (2) se il valore da rimuovere è inferiore a quello del nodo corrente procede la ricerca nel sottoalbero di sinistra
 * (3) se il valore da rimuovere è maggiore di quello del nodo corrente procede la ricerca nel sottoalbero destro
 * (4) se il nodo da rimuovere quello corrente la faccenda diventa più complessa
 * (4a) per eliminare il nodo corrente è sufficiente modificare il riferimento che va dal genitore al nodo corrente ponendolo uguale a NULL
 * (4b) se il nodo da eliminare non ha figli il corrispondente riferimento nel genitore viene posto a null
 * (4c) se il nodo da eliminare ha un solo figlio si modifica il collegamento che dal genitore puntaa al nodo stesso facendolo puntare all'unico figlio del nodo corrente
 * (4d) se il nodo da eliminare ha due figli il procedimento per l'eliminazione diviene più complesso:
 * (4d1) invece di eliminare il nodo è più semplice sostituire il dato in esso contenuto con il successivo dato della sequenza ordinata
 * (4d2) per identificare tale dato basta cercare il valore minimo presente nel sottoalbero destro del nodo da eliminare
 * (4d3) continuando poi, in tale sottoalbero, a seguire il collegamento che porta verso il figlio sinistro
 * (4d4) ... Una volta raggiunto il nodo privo di figlio sinistro, tale nodo è quello che contiene il dato di valore minore all'interno del sottoalbero in questione.
 * (4d5) memorizzare il valore contenuto in questo nodo ed eliminarlo
 * (4d6) memorizzare nel nodo da eliminare il dato che era contenuto nel nodo appena eliminato
 * 
 * 
 * 
 * 
 * Nella struttura di dati appena descritta la velocità dell'inserimento della rimozione dipende dalla forma dell'albero:
 * Se l'albero è bilanciato tali operazioni risultano veloci, altrimenti lente.
 * In un albero bilanciato tutti i percorsi che vanno dal nodo radice al nido foglia hanno approssimativamente la stessa lunghezza.
 * L'altezza dell'albero è data dal numero di nodi che si trovano sul percorso più lungo che va dal nodo radice al nodo foglia.
 * 
 * Dato che in una struttura di questo tipo le operazioni agiscono su un solo percorso, il tempo di elaborazione dei dati è proporzionale all'altezza dell'albero e non al numero totale dei nodi in esso presenti.
 * 
 * Per un albero completamente riempito si ha h=log_2 (n+1).
 * 
 * Un albero di ricerca binaria va bene per dati casuali; se si utilizzano dati ordinati o aventi lunghe sequenze ordinate occorre utilizzare strutture ad albero più sofisticate.
 */


package com_antoniomaulucci_AlberiDiRicercaBinari.BinarySearchTree;

/**
 * Questa classe implementa un albero di ricerca binario i cui nodi contengono oggett di tipo Comprable.
 * @author Antonio Maulucci
 */
public class BinarySearchTree {
	
	private String toPrint; //variabile che salva la stringa con tutti i dati dell'albero
	
	//definizione di Nodo dell'albero
	/**
	 * Un nodo di un albero memorizza un dato e i riferimenti a due nodi, il figlio sinistro e quello destro.
	 * @author Antonio Maulucci
	 */
	class Node
	{
		//public Comparable data; //Questa variabile immagazzina il dato contenuto nel nodo e NON è tipizzata
		private Comparable<Comparable> data; //Questa variabile immagazzina il dato contenuto nel nodo ed è tipizzata
		private Node left; //Questa variabile contiene il riferimento al nodo figlio sinistro
		private Node right; //Questa variabile contiene il riferimento al nodo figlio destro
		
		/**
		 * Questo metodo inserisce un nuovo nodo come figlio del nodo corrente.
		 * @param newNode Il nodo da inserire.
		 */
		public void addNode(Node newNode)
		{
			int comp = newNode.data.compareTo(data); //Questa variabile, di tipo intero, salva il risultato della comparazione tra il dato del nodo corrente e il dato del nodo da aggiungere
			
			if (comp < 0) { //Se la variabile comp è inferiore a zero vuol dire che il dato contenuto nel nodo da inserire è inferiore a quello del nodo corrente e pertanto il nodo deve essere aggiunto come figlio sinistro del nodo corrente
				if (left==null) left=newNode; //Se il figlio sinistro è uguale a null vuol dire che questo non esiste e pertanto il nuovo nodo diventa il figlio sinistro del nodo corrente
				else left.addNode(newNode); //Altrimenti, se il figlio sinistro già esiste, viene chiamato il corrente metodo (per l'aggiunta di un nodo) sul figlio sinistro del nodo corrente a cui viene passato (come parametro) il nodo da aggiungere
			} else if (comp > 0) { //Se la variabile comp è maggiore di zero vuol dire che il dato contenuto nel nodo da inserire è maggiore di quello contenuto nel nodo corrente e pertanto il nuovo nodo deve essere aggiunto come figlio destro del nodo corrente
				if (right==null) right = newNode; //Se il figlio destro è uguale a null vuol dire che questo non esiste e pertanto il nuovo nodo diventa il figlio destro del nodo corrente
				else right.addNode(newNode); //Altrimenti, se il figlio destro già esiste, viene chiamato il corrente metodo (per l'aggiunta di un nodo) sul figlio destro del nodo corrente a cui viene passato (come parametro) il nodo da aggiungere
			} //end of else-if
		} //end of "addNode" method
		
		
		/**
		 * Questo metodo visualizza questo nodo e tutti i suoi discendenti in successione ordinata.
		 */
		public void printNodes()
		{
			/*
			 * Questo metodo verifica che esista il nodo sinistro, se non esiste verifica che esista il nodo destro.
			 * Qualora uno dei due nodi esistesse, su di esso viene chiamato il metodo corrente, che verrà così chiamato fino a quando non si giunge ad un nodo foglia il quale verrà stampato;
			 * Poi si ritorna indietro sino ad arrivare al nodo radice.
			 * In questo modo, procedendo ricorsivamente, si stampa l'intero albero di ricerca binaria.
			 */
			
			if (left != null) left.printNodes(); //Se il nodo sinistro esiste chiama su questo il metodo corrente per la stampa dell'albero
			
			System.out.println(data + " "); //Viene stampato il dato del nodo corrente seguito da uno spazio che lo separerà dal dato che verrà stampato successivamente
			toPrint+=(data + " -> ");
			
			if (right != null) right.printNodes(); //Se il nodo destro esiste chiama su questo il metodo corrente per la stampa dell'albero
			
		} //end of "printNodes" method
		
		
	} //end of "Node" class
	
	
	
	//variabili
	private Node root; //creazione del nodo radice
	
	
	public BinarySearchTree()
	{
		root = null; //Il nodo radice viene inizializzato a NULL perché all'inizio dell'esecuzione del codice esso non contiene dati. Questo nodo è uguale a NULL quando l'albero è vuoto.
		toPrint="";
	} //end of builder
	
	
	/*
	 * I metodi di questa classe possono essere tipizzati
	 * ad esempio se si intende utilizzare questa classe solo al fine
	 * di immagazzinare numeri interi all'interno dell'albero di ricerca binario
	 * si possono tipizzare i metodi seguendo lo schema seguente
	 * nomeMetodo(Comparable<TipoDiDato> nomeParametro)
	 * es.: Il metodo { public void add (Comparable o)
	 * può essere tipizzato in questo modo
	 * { public void add (Comparable<Integer> o) }
	 */
	/**
	 * Questo metodo inserisce un nuovo modo nell'albero.
	 * @param o L'oggetto da inserire.
	 */
	public void add (Comparable o)
	{
		
		Node newNode = new Node(); //Creazione di un nuovo nodo che verrà aggiunto all'albero
		
		newNode.data = o; //Aggiunta dell'oggetto da inserire nel nodo al nodo
		
		/*
		 * Il nudo che stiamo creando sarà un nodo foglia
		 * Pertanto non avrà nodi figli, nè sinistro, nè destro
		 */
		newNode.left = null;
		newNode.right = null;
		
		//AGGIUNTA DEL NODO ALL'ALLBERO
		//se l'albero è vuoto ::: il nodo radice è nullo ::: usare il nodo come nodo radice
		if (root == null) root=newNode;
		//altrimenti ::: se il nodo radice non è nullo
		else root.addNode(newNode); //utilizzare il metodo addNode del nodo radice (analizzare il codice sorgente della classe Node per comprenderne il funzionamento)
		
	} //end of "add" method
	
	
	
	
	/**
	 * Cerca un oggetto nell'albero.
	 * @param o L'oggetto da cercare.
	 * @return Vero se l'oggetto è stato trovato, altrimenti falso.
	 */
	public boolean find(Comparable o)
	{
		
		Node current = root; //Si utilizza questa variabile di tipo Node per scandire l'albero. Essa assume come valore iniziale la posizione root (radice dell'albero) e successivamente quello dei nodi successivi al fine di rappresentare il nodo corrente dell'albero
		
		while (current != null) { //mentre current (vedi il commento della variabile) è diverso da null ovvero l'albero non è vuoto
			
			/*
			 * questa variabile salva il valore intero che deriva
			 * dalla comparazione dell'elemento contenuto nel nodo corrente
			 * e l'oggetto da cercare
			 */
			int d = current.data.compareTo(o);
			
			if (d==0) return true; //se d è uguale a 0 vuol dire che gli oggetti sono uguali e pertanto viene restituito true e viene interrotta l'esecuzione del metodo
			else if (d>0) current = current.left; //se d è maggiore di 0 vuol dire che bisogna cercare nel sottoalbero sinistro rispetto al nodo corrente perché il vaore cercato è inferiore a quello corrente === scorrere l'albero e rieseguire il codice del ciclo while
			else current=current.right; //se d è minore di 0 vuol dire che bisogna cercare nel sottoalbero destro rispetto al nodo corrente perché il valore cercare è maggiore di quello corrente === scorrere l'albero e rieseguire il codice del ciclo while
			
		} //end of while
		
		return false; //se il metodo giunge a questo punto vuol dire che l'oggetto non è stato rinvenuto pertanto il metodo restituisce false
		
	} //end of "find" method
	
	
	
	
	/**
	 * Questo metodo elimina un nodo dell'albero. Se l'oggetto non è contenuto nell'albero non viene effettuata nessuna operazione.
	 * @param o L'oggetto contenuto nel nodo da eliminare.
	 */
	public void remove(Comparable o)
	{
		Node toBeRemoved = root; //questa variabile di tipo nodo immagazzina il valore del nodo radice in modo da poter effettuare la scansione dell'albero
		Node parent = null; //questa variabile contiene il riferimento al nodo genitore del nodo corrente. All'inizio del metodo il nodo corrente è il nodo radice il quale non ha genitori pertanto tale variabile è NULL
		
		boolean found = false; //questa variabile diventa vera nel momento in cui l'elemento da eliminare è stato trovato nell'albero
		
		
		//fintanto che l'elemento da eliminare non è stato trovato e il nodo corrente sia diverso da null
		while(!found && toBeRemoved!=null) {
			
			/*
			 * questa variabile salva il valore intero che deriva
			 * dalla comparazione dell'elemento contenuto nel nodo corrente
			 * e l'oggetto da cercare (eliminare)
			 */
			int d = toBeRemoved.data.compareTo(o);
			
			
			if (d==0) { //se gli elementi corrispondono
				found = true; //la variabile che verifica se l'elemento è stato trovato diventa vera
			} else { //altrimenti
				parent = toBeRemoved; //l'attuale nodo diviene quello genitore
				if (d>0) toBeRemoved = toBeRemoved.left; //se il valore corrente è maggiore di quello da eliminare scorrere l'albero verso sinistra ::: il nodo corrente diviene l'attuale nodo figlio sinistro
				else toBeRemoved = toBeRemoved.right; //se il valore corrente è minore di quello da eliminare scorrere l'albero verso destra ::: il nodo corrente diviene l'attuale nodo figlio destro
			} //end of else
			
		} //end of while
		
		
		/*
		 * Se il nodo da eliminare non viene trovato
		 * Interrompere il metodo senza eseguire alcuna operazione
		 * altrimenti continuare l'esecuzione del programma in maniera del tutto normale
		 */
		if (!found) return;
		
		/*
		 * CASO 4B DELL'ELIMINAZIONE ::: il nodo da eliminare non ha figli
		 */
		if (toBeRemoved.left==null && toBeRemoved.right==null) {
			if (toBeRemoved.data.compareTo(parent.data) > 0) {
				parent.right = null;
			} else {
				parent.left=null;
			} //end of else
			return;
		} //end of if
		/*
		 * CASO 4C DELL'ELIMINAZIONE ::: il nodo da eliminare ha un solo figlio
		 * Se il nodo sinistro o quello destro non esiste
		 */
		else if (toBeRemoved.left==null || toBeRemoved.right==null) {
			
			Node newChild; //nuovo nodo figlio ::: il nodo che andrà a sostituire il nodo da eliminare ::: il nodo qui memorizzat andrà a sostituire il nodo da eliminare ::: siamo nel caso 4c quindi il nodo da eliminare ha un solo figlio
			
			if (toBeRemoved.left==null) { //se il nodo da eliminare non ha un figlio sinistro si considera quello destro
				newChild = toBeRemoved.right; //Il nodo da eliminare ha un genitore e un figlio, esso verrà eliminato, pertanto il figlio del suo genitore sarà suo figlio
			} else { //altrimenti, se il nodo da eliminare non ha un figlio destro si considera quello sinistros
				newChild = toBeRemoved.right;
			} //end of else
			
			if (parent == null) { //In questo caso si ha che il nodo da eliminare è il nodo radice
				root = newChild; //Pertanto il nuovo nodo radice sarà l'unico figlio del nodo radice
			} else if (parent.left==toBeRemoved) { //Se il nodo da eliminare è il figlio sinistro del genitore
				parent.left = newChild; //Il riferimento al figlio sinistro del genitore viene modificato nel nodo che deve sostituire tale figlio (vedi sopra per maggiori dettagli)
			} else { //Se il nodo da eliminare è il figlio destro del genitore...
				parent.right = newChild;
			} //end of else
			
			return; //Dopo aver effettuato la modifica del riferimento (vedi sopra) interrompi l'esecuzione del metodo
			
		} //end of if
		
		
		
		/*
		 * CASO 4D ::: Il nodo da eliminare ha entrambi i figli
		 */
		//
		/*
		 * Il nodo toBeRemoved contiene i dati del nodo radice
		 * Pertanto la variabile smallestParent contiene tale nodo
		 * Mentre la variabile smallest contiene il riferimento al nodo figlio destro del nodo radice
		 */
		Node smallestParent = toBeRemoved; //Questa variabile immagazzina il genitore del nodo contenente il valore più piccolo
		Node smallest = toBeRemoved.right; //Questa variabile immagazzina il nodo contenente il valore più piccolo ... tale nodo viene cercato all'interno del sottoalbero destro
		
		//Mentre il nodo figlio sinistro del nodo che contiene il valore più piccolo è diverso da null
		while (smallest.left!=null) {
			//Con le due istruzioni seguenti si scorre l'albero fintanto che questo (l'alebero) non ha più figli sinistri ovvero si giunge ad un nodo foglia <<vedi punti 4d3 e 4d4>>
			smallestParent = smallest;
			smallest = smallest.left;
		} //end of while
		
		
		
		/*
		 * In questo punto del programma la variabile smallest contiene il dato più piccolo del sottoalbero
		 * 
		 * Pertanto, seguendo i passi 4d4 e 4d5, il nodo contenente il dato più piccolo verrà memorizzato nella variabile "toBeRemoved"
		 */
		toBeRemoved.data = smallest.data; //Memorizzare il valore del nodo contenente il valore più piccolo <<passi 4d4 e 4d5>>
		
		//Memorizzare nel nodo da eliminare il dato che era contenuto nel nodo appena eliminato <<passo 4d6>>
		/*
		 * Se il genitore del nodo contenente il valore più piccolo è il nodo da eliminare (toBeRemoved)
		 * Il riferimento al figlio destro del genitore del nodo contenente il valore più piccolo
		 * Punterà al figlio destro del nodo contenente il valore più piccolo
		 */
		//if (smallestParent.data == toBeRemoved.data) {
		if (smallestParent.data.equals(toBeRemoved.data)) {
			smallestParent.right = smallest.right;
			//smallestParent.right = null;
		}
		/*
		 * Altrimenti, se il genitore del nodo contenente il valore più piccolo è diverso dal nodo da eliminare
		 * Il riferimento al figlio sinistro del genitore del nodo contenente il valore più piccolo
		 * Punterà al figlio sinistro del nodo contenente il valore più piccolo
		 */
		else {
			//smallestParent.left = smallest.right;
			smallestParent.left = smallest.right;
		}
		
	} //end of "remove" method
	
	
	
	
	
	/**
	 * Questo metodo visualizza il contenuto dell'albero in successione ordinata.
	 */
	public void print()
	{
		/*
		 * Questa strategia per la stampa dei dati viene chiamata "visita in ordine simmetrico"
		 * Perché prevede la visita del sottoalbero sinistro, della radice, e successivamente del sottoalbero destro.
		 * 
		 * Esistono altre due strategie per la visita di un albero:
		 * (a) visita in ordine anticipato: si visita la radice, si visita il suo sottoalbero sinistro e poi il suo sottoalbero destro
		 * (b) visita in ordine posticipato: si visita il sottoalbero sinistro della radice, si visita il sottoalbero destro della radice, si visita la radice
		 */
		if (root != null) root.printNodes(); //Se il nodo radice è diverso da null vuol dire che l'albero non è vuoto pertanto viene chiamato il metodo printNodes() del nodo radice
		System.out.println(); //Viene stampata una riga vuota con l'andata a capo
	}
	
	
	/**
	 * Il metodo per la stampa viene riscritto al fine di poter adattare il metodo alla gui del programma
	 * @return Una stringa contenente tutti i dati contenuti nell'albero nella sequenza in cui verrebbero stampati dal metodo print()
	 */
	public String printGui()
	{
		toPrint=""; //reset the toPrint variable argument
		if (root!=null) root.printNodes();
		return toPrint;
	} //end of printGui
	
	

} //end of "BinarySearchTree" class
