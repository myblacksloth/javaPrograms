package com_antomau_Catasto.Classi;

import java.util.Scanner;

public class Abitazione {
	
	/**
	 * metodo costruttore per l'abitazioe di tipo Appartamento.
	 * @param type
	 * @param id
	 * @param codfis
	 * @param name
	 * @param street
	 * @param num
	 * @param city
	 * @param floor
	 * @param rooms
	 * @param price
	 */
	public Abitazione(String type, String id, String codfis, String name, String street, int num, String city, int floor, int rooms, int surface, double price) //appartamento
	{
		//utilizzo un if per evitare che questo costruttore venga usato con le abitazioni indipendenti
		if (!type.equals("Appartamento")) return;
		this.type = type;
		this.id = id;
		this.codfis = codfis;
		this.name = name;
		this.street = street;
		this.num = num;
		this.city = city;
		this.floor = floor;
		this.rooms = rooms;
		this.surface = surface;
		this.price = price;
		//annullo i parametri non tipici degli appartamenti
		this.garden = false;
		this.floorsnum = -1;
	}
	
	/**
	 * metodo costruttore per l'abitazione di tipo Indipendente.
	 * @param type
	 * @param id
	 * @param codfis
	 * @param street
	 * @param num
	 * @param city
	 * @param floorsnum
	 * @param garden
	 * @param price
	 */
	public Abitazione(String type, String id, String codfis, String street, int num, String city, int floorsnum, boolean garden, double price) //indipendente
	{
		//utilizz un if per evitare che questo costruttore venga usato con le abitazioni appartamento
		if (!type.equals("Indipendente")) return;
		this.type = type;
		this.id = id;
		this.codfis = codfis;
		this.street = street;
		this.num = num;
		this.city = city;
		this.floorsnum = floorsnum;
		this.garden = garden;
		this.price = price;
		//annullo i parametri non tipici delle abitazioni indipendenti
		this.name = null;
		this.floor = -1;
		this.rooms = -1;
		this.surface = -1;
	}
	
	/**
	 * costruttore vuoto per permettere la creazione di un nuovo oggetto le cui caratteristiche vengono prese da file.
	 */
	public Abitazione()
	{
	}
	
	public void setType(String type)
	{
		this.type = type;
	}
	
	public String getType()
	{
		return type;
	}
	
	public void setid(String id)
	{
		this.id = id;
	}
	
	public String getid()
	{
		return id;
	}
	
	public void setCodfis(String codfis)
	{
		this.codfis = codfis;
	}
	
	public String getCodfis()
	{
		return codfis;
	}
	
	public void setStreet(String street)
	{
		this.street = street;
	}
	
	public String getStreet() {
		return street;
	}
	
	public void setCity(String city)
	{
		this.city = city;
	}
	
	public String getCity()
	{
		return city;
	}
	
	public void setName(String name)
	{
		//questo paramentro appartiene solo agli appartamenti
		if (!type.equals("Appartamento")) return;
		this.name = name;
	}
	
	public String getName()
	{
		if (!type.equals("Appartamento")) return null;
		return name;
	}
	
	public void setNum(int num)
	{
		this.num = num;
	}
	
	public int getNum()
	{
		return num;
	}
	
	public void setFloor(int floor)
	{
		//questa caratteristica appartiene solo agli appartamenti
		if (!type.equals("Appartamento")) return;
		this.floor = floor;
	}
	
	public int getFloor()
	{
		if (!type.equals("Appartamento")) return (-1);
		return floor;
	}
	
	public void setFloorsnum(int floorsnum)
	{
		//questa caratteristica appartiene solo alle abitazioni indipendenti
		if (!type.equals("Indipendente")) return;
		this.floorsnum = floorsnum;
	}
	
	public int getFloorsnum()
	{
		if (!type.equals("Indipendente")) return (-1);
		return floorsnum;
	}
	
	public void setRooms(int rooms)
	{
		//questa caratteristica appartiene solo agli appartamenti
		if (!type.equals("Appartamento")) return;
		this.rooms = rooms;
	}
	
	public int getRooms()
	{
		if (!type.equals("Appartamento")) return (-1);
		return rooms;
	}
	
	public void setSurface(int surface)
	{
		//questa caratteristica appartiene solo agli appartamenti
		if (!type.equals("Appartamento")) return;
		this.surface = surface;
	}
	
	public int getSurface()
	{
		if (!type.equals("Appartamento")) return (-1);
		return surface;
	}
	
	public void setGarden(boolean garden)
	{
		if (!type.equals("Indipendente")) return;
		this.garden = garden;
	}
	
	public boolean getGarden()
	{
		if (!type.equals("Indipendente")) return false;
		return garden;
	}
	
	public void setPrice(double price)
	{
		this.price = price;
	}
	
	public double getPrice()
	{
		return price;
	}
	
	/**
	 * Questo metodo legge un'abitazione da file e la crea.
	 * @param in Scanner per il file delle Abitazioni.
	 * @return Una nuova abitazione.
	 */
	public Abitazione read(Scanner in)
	{
		Abitazione a = null;
		
		try
		{
			
			if (!in.hasNextLine()) return null;
			
			String type = in.nextLine();
			
			if (type.equals("Appartamento"))
			{
				
				String id, name, street, city;
				int num, floor, rooms, surface;
				double price;
				
				if (in.hasNextLine()) id = in.nextLine();
				else return null;
				
				if (in.hasNextLine()) codfis = in.nextLine();
				else return null;
				
				if (in.hasNextLine()) name = in.nextLine();
				else return null;
				
				if (in.hasNextLine()) street = in.nextLine();
				else return null;
				
				if (in.hasNextLine()) num = Integer.parseInt(in.nextLine());
				else return null;
				
				if (in.hasNextLine()) city = in.nextLine();
				else return null;
				
				if (in.hasNextLine()) floor = Integer.parseInt(in.nextLine());
				else return null;
				
				if (in.hasNextLine()) rooms = Integer.parseInt(in.nextLine());
				else return null;
				
				if (in.hasNextLine()) surface = Integer.parseInt(in.nextLine());
				else return null;
				
				if (in.hasNextLine()) price = Double.parseDouble(in.nextLine());
				else return null;
				
				a = new Abitazione(type, id, codfis, name, street, num, city, floor, rooms, surface, price);
				
			}
			else if (type.equals("Indipendente"))
			{
				
				String id, codfis, street, city;
				int num, floorsnum;
				boolean garden=false;
				double price;
				
				if (in.hasNextLine()) id = in.nextLine();
				else return null;
				
				if (in.hasNextLine()) codfis = in.nextLine();
				else return null;
				
				if (in.hasNextLine()) street = in.nextLine();
				else return null;
				
				if (in.hasNextLine()) num = Integer.parseInt(in.nextLine());
				else return null;
				
				if (in.hasNextLine()) city = in.nextLine();
				else return null;
				
				if (in.hasNextLine()) floorsnum = Integer.parseInt(in.nextLine());
				else return null;
				
				if (in.hasNextLine())
				{
					if (in.nextLine().equals("true")) garden=true;
				}
				else return null;
				
				if (in.hasNextLine()) price = Double.parseDouble(in.nextLine());
				else return null;
				
				a = new Abitazione(type, id, codfis, street, num, city, floorsnum, garden, price);
				
			}
			/*
			 * se non viene trovata la tipologia di dato cercata
			 * lo scanner verfica che esiste un'ulteriore posizione nel file
			 * e avanza verso questa al fine di poter facilitare la ricerca
			 * alla successiva esecuzione del ciclo while
			 */
			else {
				if (in.hasNextLine()) in.nextLine();
				return null;
			}
			
		} catch (Exception fileexception)
		{
			fileexception.printStackTrace();
		}
		
		return a;
	}
	
	@Override
	public String toString()
	{
		String s="";
		
		if (type.equals("Appartamento"))
		{
			s += "Abitazione[ type=" + type + ", id=" + id + ", codice fiscale proprietario=" + codfis + ", nome palazzo=" + name + ", via=" + street + ", numero civico=" + num +
					", comune=" + city + ", piano=" + floor + ", numero di stanze=" + rooms + ", metri quadri=" + 
					surface + ", prezzo=" + price + "]";
		}
		else if (type.equals("Indipendente"))
		{
			s += "Abitazione[ type=" + type + ", id=" + id + ", codice fiscale proprietario=" + codfis + ", via=" + street + ", numero civico=" + num +
					", comune=" + city + ", numero di piani=" + floorsnum + ", giardino=" + garden + ", prezzo=" + price + "]";
		}
		
		return s;
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((codfis == null) ? 0 : codfis.hashCode());
		result = prime * result + floor;
		result = prime * result + floorsnum;
		result = prime * result + (garden ? 1231 : 1237);
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + num;
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + rooms;
		result = prime * result + ((street == null) ? 0 : street.hashCode());
		result = prime * result + surface;
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Abitazione other = (Abitazione) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (codfis == null) {
			if (other.codfis != null)
				return false;
		} else if (!codfis.equals(other.codfis))
			return false;
		if (floor != other.floor)
			return false;
		if (floorsnum != other.floorsnum)
			return false;
		if (garden != other.garden)
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (num != other.num)
			return false;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (rooms != other.rooms)
			return false;
		if (street == null) {
			if (other.street != null)
				return false;
		} else if (!street.equals(other.street))
			return false;
		if (surface != other.surface)
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}
	
	
	
	
	//variabili d'istanza
	//tipologia, codice identificativo, codice fiscale proprietario, via, comune, nome palazzo
	String type, id, codfis, street, city, name;
	//numero civico, piano, numero di piani, numero di stanze, superficie m3
	int num, floor, floorsnum, rooms, surface;
	//presenza o meno del giardino
	boolean garden;
	//prezzo
	double price;
}
